document.addEventListener('DOMContentLoaded',()=>{
 const menu=document.querySelector('.menu'); const btn=document.querySelector('.hamburger'); if(btn){btn.addEventListener('click',()=>menu.classList.toggle('open'))}
 const counters=document.querySelectorAll('[data-count]'); const io=new IntersectionObserver(entries=>{entries.forEach(entry=>{if(entry.isIntersecting){const el=entry.target; const target=+el.dataset.count; let current=0; const step=Math.max(1,Math.ceil(target/45)); const tick=()=>{current+=step; if(current>=target){el.textContent=target;return} el.textContent=current; requestAnimationFrame(tick)}; tick(); io.unobserve(el)}})},{threshold:.4}); counters.forEach(c=>io.observe(c));
});
