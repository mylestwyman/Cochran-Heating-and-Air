Cochran Heating & Air website

Open index.html in a browser to view the website.
All pages are linked through the navigation. CSS is in styles.css and JavaScript is in script.js.
Replace the visual placeholders with real photos when available.
